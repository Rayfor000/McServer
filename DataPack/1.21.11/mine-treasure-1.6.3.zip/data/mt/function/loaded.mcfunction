execute store result score $difficulty mt.var run difficulty
function mt:settings/progression/standard
function mt:settings/frequency/standard
data modify storage mt:settings 3 set value {"type":"minecraft:number_range","key":"3","width":200,"label":{"translate":"mt.cQDAzOsd2iy","fallback":"Loot Table Rolls"},"start":5,"end":50,"step":1,"initial":20}
function mt:settings/despawn/standard
data modify storage mt:settings 5 set value {"type":"minecraft:boolean","key":"5","label":{"translate":"mt.0BhPuViAMuU","fallback":"Disable Structure Spawning Items"},"initial":0,"on_true":"1","on_false":"0"}
data modify storage mt:settings 6 set value {"type":"minecraft:boolean","key":"6","label":{"translate":"mt.7JRqV6QhlqO","fallback":"Disable Global Legendary/Mythical Sound"},"initial":0,"on_true":"1","on_false":"0"}
data modify storage mt:settings 7 set value {"type":"minecraft:boolean","key":"7","label":{"translate":"mt.4iF7eAVpuY5","fallback":"Disable Common Treasures"},"initial":0,"on_true":"1","on_false":"0"}
data modify storage mt:settings 8 set value {"type":"minecraft:boolean","key":"8","label":{"translate":"mt.fujSfHIOHvl","fallback":"Disable Rare Treasures"},"initial":0,"on_true":"1","on_false":"0"}
data modify storage mt:settings 9 set value {"type":"minecraft:boolean","key":"9","label":{"translate":"mt.joooPcRn3cd","fallback":"Disable Epic Treasures"},"initial":0,"on_true":"1","on_false":"0"}
data modify storage mt:settings 10 set value {"type":"minecraft:boolean","key":"10","label":{"translate":"mt.caZl1K3xi1b","fallback":"Disable Legendary Treasures"},"initial":0,"on_true":"1","on_false":"0"}
data modify storage mt:settings 11 set value {"type":"minecraft:boolean","key":"11","label":{"translate":"mt.0mlBzreTmW6","fallback":"Disable Mythical Treasures"},"initial":0,"on_true":"1","on_false":"0"}
data modify storage mt:settings 12 set value {"type":"minecraft:boolean","key":"12","label":{"translate":"mt.eLz91EoC5x9","fallback":"Disable Runes"},"initial":0,"on_true":"1","on_false":"0"}
data modify storage mt:settings 13 set value {"type":"minecraft:boolean","key":"13","label":{"translate":"mt.0n9tu7iUO7T","fallback":"Disable Detonation Mines"},"initial":0,"on_true":"1","on_false":"0"}
data modify storage mt:settings 14 set value {"type":"minecraft:boolean","key":"14","label":{"translate":"mt.isNq5BLKXO9","fallback":"Disable Silk Touch Treasures"},"initial":0,"on_true":"1","on_false":"0"}
data modify storage mt:settings 15 set value {"type":"minecraft:boolean","key":"15","label":{"translate":"mt.hUTkdylmmYg","fallback":"Disable Bedrock/Reinforced Deepslate"},"initial":0,"on_true":"1","on_false":"0"}
data modify storage mt:settings 16 set value {"type":"minecraft:boolean","key":"16","label":{"translate":"mt.gpYFmPXTL9U","fallback":"Disable Giga Drill Effect"},"initial":0,"on_true":"1","on_false":"0"}
data modify storage mt:settings 17 set value {"type":"minecraft:boolean","key":"17","label":{"type":"translatable","initial":0,"on_true":"1","on_false":"0","translate":"mt.c93d9RYnWfg","fallback":"Vanilla Mode"}}
scoreboard players set $vanilla_mode mt.var 0
scoreboard players set $progression mt.var 2
scoreboard players set $frequency mt.var 2
scoreboard players set #load1 mt.var 1

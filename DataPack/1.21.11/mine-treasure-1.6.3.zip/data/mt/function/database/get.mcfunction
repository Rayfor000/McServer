$data modify storage mt:write data merge from storage mt:database "$(UUID)"

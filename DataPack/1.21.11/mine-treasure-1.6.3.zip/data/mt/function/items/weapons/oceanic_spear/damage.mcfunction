$damage @s 13 mt:oceanic_spear by $(hexUUID)

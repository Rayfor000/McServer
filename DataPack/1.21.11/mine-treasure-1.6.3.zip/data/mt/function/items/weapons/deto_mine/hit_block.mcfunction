scoreboard players set #mt.hit mt.ray_line 1
tag @s remove mt.deto_mine
execute align xyz run summon armor_stand ~0.5 ~ ~0.5 {"NoGravity":0,"Silent":1,"Invulnerable":1,"Invisible":1,"Tags":["mt.entity","mt.deto_mine"]}
scoreboard players set @e[type=armor_stand,tag=mt.deto_mine,distance=..1.8,sort=nearest] mt.self_kill 100

execute if score #mt.hit mt.ray_line matches 0 positioned ~-0.05 ~-0.05 ~-0.05 as @e[type=!#mt:non_entity,tag=!mt.laser_scope,dx=0,sort=nearest] run function mt:items/weapons/laser/check_hit_entity
particle minecraft:end_rod ~ ~ ~ 0 0 0 0 1 force
execute if block ~ ~ ~ #mt:blocks run function mt:items/weapons/laser/hit_block with storage mt:write data
scoreboard players add #mt.distance mt.ray_line 1
execute if score #mt.hit mt.ray_line matches 0 if score #mt.distance mt.ray_line matches ..6000 positioned ^ ^ ^0.05 run function mt:items/weapons/laser/ray

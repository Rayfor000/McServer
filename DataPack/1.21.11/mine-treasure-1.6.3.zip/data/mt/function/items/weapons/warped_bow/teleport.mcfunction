$execute as @s run tp $(hexUUID) ^ ^ ^

effect give @s unluck 30 100 true

schedule function mt:items/totems/death_totem/as_player 1t append

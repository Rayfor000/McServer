schedule function mt:items/totems/assassination_totem/as_player 1t append

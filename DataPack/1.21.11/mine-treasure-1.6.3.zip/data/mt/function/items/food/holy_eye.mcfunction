summon area_effect_cloud ~ ~0.5 ~ {"custom_particle":{"type":"dust","color":[0.31,1.0,0.098],"scale":1},"ReapplicationDelay":10,"Radius":5,"RadiusPerTick":-0.01,"RadiusOnUse":-0.1,"DurationOnUse":20,"Age":200,"WaitTime":200,"potion_contents":{"custom_color":3342116,"custom_effects":[{"id":"minecraft:poison","amplifier":2,"duration":20,"show_particles":1}]}}
tellraw @s ["",{"text":"[","color":"gray"},{"selector":"@s","color":"white"},{"text":"] ","color":"gray"},{"text":"UGH, DEFINTIELY NOT HOLY *VOMITS*","color":"dark_green"}]
advancement revoke @s only mt:items/food/holy_eye

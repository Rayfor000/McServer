data merge entity @s {"Silent":1,"HasVisualFire":1,"LifeTime":200}

data merge entity @s {"damage":5,"crit":1}

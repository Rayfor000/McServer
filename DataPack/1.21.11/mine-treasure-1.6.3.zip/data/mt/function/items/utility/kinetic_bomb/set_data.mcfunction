$summon armor_stand ~ ~ ~ {"NoGravity":0,"Motion":$(motion),"Invulnerable":1,"Small":1,"Invisible":1,"equipment":{"saddle":{"id":"minecraft:oak_button","count":1,"components":{"minecraft:item_model":"air","minecraft:enchantments":{"mt:technical/kinetic_blast":20}}}}}
kill @s

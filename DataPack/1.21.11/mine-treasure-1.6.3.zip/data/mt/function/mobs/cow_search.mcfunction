execute if entity @s[tag=mt.dolphins_grace] run data merge entity @s {"Type":"brown","stew_effects":[{"id":"minecraft:dolphins_grace","duration":2001}]}
execute if entity @s[tag=mt.lucky] run data merge entity @s {"Type":"brown","stew_effects":[{"id":"minecraft:luck","duration":6001}]}
execute if entity @s[tag=mt.levi] run data merge entity @s {"Type":"brown","stew_effects":[{"id":"minecraft:levitation","duration":6001}]}
execute if entity @s[tag=mt.health] run data merge entity @s {"Type":"brown","stew_effects":[{"id":"minecraft:health_boost","duration":6001}]}
execute if entity @s[tag=mt.slowfall] run data merge entity @s {"Type":"brown","stew_effects":[{"id":"minecraft:slow_falling","duration":6001}]}
execute if entity @s[tag=mt.saturation] run data merge entity @s {"Type":"brown","stew_effects":[{"id":"minecraft:saturation","duration":601}]}

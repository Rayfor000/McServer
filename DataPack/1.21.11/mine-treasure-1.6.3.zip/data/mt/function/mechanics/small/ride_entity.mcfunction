ride @a[scores={mt.small_hit=0},distance=..6,limit=1] mount @s[type=!player]

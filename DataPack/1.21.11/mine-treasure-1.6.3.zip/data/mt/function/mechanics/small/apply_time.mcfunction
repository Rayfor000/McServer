$scoreboard players set @s mt.small $(duration)

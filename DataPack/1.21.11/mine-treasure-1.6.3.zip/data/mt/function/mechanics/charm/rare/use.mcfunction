advancement revoke @s only mt:mechanics/charm/rare
advancement revoke @s only mt:mechanics/charm/timer
scoreboard players add @s mt.luck 120
title @s actionbar {"color":"gray","translate":"mt.c9rtjbqmTVt","fallback":"Activated Rare Charm!"}
playsound minecraft:entity.firework_rocket.launch ambient @a[distance=..7] ~ ~ ~1 1.2 1

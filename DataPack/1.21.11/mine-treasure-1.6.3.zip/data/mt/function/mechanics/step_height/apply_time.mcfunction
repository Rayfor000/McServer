$scoreboard players set @s mt.step_height $(duration)

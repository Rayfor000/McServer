$scoreboard players set @s mt.reach $(duration)

$scoreboard players set @s mt.light $(duration)

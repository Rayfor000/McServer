$scoreboard players set @s mt.big $(duration)

scoreboard players set @s mt.hit_cooldown 0

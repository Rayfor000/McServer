particle minecraft:falling_dust{block_state:"minecraft:gray_concrete"} ~ ~1 ~ 0.5 0.5 0.5 0 15
particle minecraft:block{block_state:"minecraft:gray_concrete"} ~ ~1 ~ 0.5 0.5 0.5 0 15
playsound enchantmentplus:enchant.weakening.hit player @a
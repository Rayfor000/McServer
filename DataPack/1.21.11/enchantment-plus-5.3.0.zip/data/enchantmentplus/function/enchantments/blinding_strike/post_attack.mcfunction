playsound enchantmentplus:enchant.blinding_strike.blind player @a
execute anchored eyes positioned ^ ^ ^ run particle minecraft:squid_ink ~ ~ ~ 0.5 0.5 0.5 0 1
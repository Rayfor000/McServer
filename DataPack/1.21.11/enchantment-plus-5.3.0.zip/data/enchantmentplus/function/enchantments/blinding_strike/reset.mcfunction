attribute @s minecraft:follow_range base reset
tag @s remove eplus.blinded
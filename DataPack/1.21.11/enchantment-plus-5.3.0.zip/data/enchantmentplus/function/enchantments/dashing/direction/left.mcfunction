execute anchored feet rotated ~90 0 run function enchantmentplus:enchantments/dashing/particles
function enchantmentplus:enchantments/dashing/dash
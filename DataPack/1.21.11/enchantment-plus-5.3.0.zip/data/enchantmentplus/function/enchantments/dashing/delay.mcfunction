execute if score @s eplus.dashing_delay matches 1.. run scoreboard players remove @s eplus.dashing_delay 1
execute if score @s eplus.dashing_delay matches 0 run title @s actionbar {"translate":"enchantmentplus.l73GxWWvVC3","fallback":"\u00A7ADashing is ready!"}
execute if score @s eplus.dashing_delay matches 0 run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 2
execute if score @s eplus.dashing_delay matches 1.. run advancement revoke @s only enchantmentplus:enchantments/dashing_delay
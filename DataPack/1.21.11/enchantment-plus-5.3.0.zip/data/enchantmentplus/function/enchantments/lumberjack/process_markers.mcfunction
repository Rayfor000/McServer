scoreboard players add @s eplus.temp 1
execute if score @s eplus.temp matches 200.. run return run kill @s
execute if block ~ ~ ~ #minecraft:air run function enchantmentplus:enchantments/lumberjack/block_broken with entity @s data
$execute unless block ~ ~ ~ $(LumberjackBlockId) run return run kill @s
execute if entity @e[type=minecraft:marker,tag=eplus.lj_marker] run schedule function enchantmentplus:enchantments/lumberjack/schedule 1t
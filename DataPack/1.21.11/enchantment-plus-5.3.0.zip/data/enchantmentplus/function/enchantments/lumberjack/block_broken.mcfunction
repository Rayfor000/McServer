tag @s add eplus.lj_break
data modify storage enchantmentplus:data Macros.LumberjackBlockId set from entity @s data.LumberjackBlockId
$execute as @p[nbt={UUID:$(UserUUID)}] run function enchantmentplus:enchantments/lumberjack/check_adjacent with storage enchantmentplus:data Macros
kill @s
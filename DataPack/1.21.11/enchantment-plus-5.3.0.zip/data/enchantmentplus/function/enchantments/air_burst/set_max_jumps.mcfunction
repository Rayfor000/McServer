execute store result score @s eplus.air_burst_jumps run data get entity @s equipment.feet.components."minecraft:enchantments"."enchantmentplus:air_burst"
scoreboard players set @s eplus.air_burst_delay 5
tag @s add eplus.air_burst_set_jumps
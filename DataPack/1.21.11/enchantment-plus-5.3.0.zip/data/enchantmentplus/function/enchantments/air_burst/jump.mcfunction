particle minecraft:cloud ~ ~ ~ 0.4 0 0.4 0 8
playsound enchantmentplus:enchant.air_burst.jump
scoreboard players remove @s eplus.air_burst_jumps 1
scoreboard players set @s eplus.air_burst_delay 8
advancement revoke @s only enchantmentplus:enchantments/air_burst_delay
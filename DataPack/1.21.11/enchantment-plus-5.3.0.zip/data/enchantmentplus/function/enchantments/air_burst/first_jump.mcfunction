advancement revoke @s only enchantmentplus:enchantments/air_burst_delay
tag @s remove eplus.air_burst_set_jumps
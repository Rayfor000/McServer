execute if entity @e[type=minecraft:marker,tag=eplus.block_marker,distance=..0.5] run kill @n[type=minecraft:marker,tag=eplus.block_marker,distance=..0.5]
execute if block ~ ~ ~ #enchantmentplus:ores_with_xp unless data entity @s SelectedItem.components."minecraft:enchantments"."minecraft:silk_touch" run function enchantmentplus:enchantments/ore_excavation/experience/calculate
execute if predicate enchantmentplus:damage_chance run function enchantmentplus:damage_item/mainhand/get_value
loot spawn ~ ~ ~ mine ~ ~ ~ mainhand
setblock ~ ~ ~ minecraft:air
execute as @e[type=minecraft:item,nbt={Age:0s},distance=..0.5] run function enchantmentplus:enchantments/ore_excavation/gather_drops
execute if entity @e[type=minecraft:marker,tag=eplus.oe_marker,tag=eplus.oe_break,distance=..10] run function enchantmentplus:enchantments/ore_excavation/check_adjacent with storage enchantmentplus:data Macros
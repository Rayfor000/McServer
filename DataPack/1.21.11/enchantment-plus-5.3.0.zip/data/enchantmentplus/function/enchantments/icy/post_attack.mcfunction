particle minecraft:block{block_state:"minecraft:blue_ice"} ~ ~1 ~ 0.5 0.5 0.5 0 15
particle minecraft:snowflake ~ ~1 ~ 0.5 0.5 0.5 0 15
playsound enchantmentplus:enchant.icy.hit player @a
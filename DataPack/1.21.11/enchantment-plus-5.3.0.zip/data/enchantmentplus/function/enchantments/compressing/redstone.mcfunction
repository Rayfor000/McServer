execute unless items entity @s container.* minecraft:redstone[!minecraft:custom_data,minecraft:count~{min:9}] run return fail
clear @s minecraft:redstone[!minecraft:custom_data] 9
give @s minecraft:redstone_block 1
execute if items entity @s container.* minecraft:redstone[!minecraft:custom_data,minecraft:count~{min:9}] run function enchantmentplus:enchantments/compressing/redstone
execute at @s run playsound enchantmentplus:enchant.compressing.compress player @s
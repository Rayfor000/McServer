execute unless items entity @s container.* minecraft:diamond[!minecraft:custom_data,minecraft:count~{min:9}] run return fail
clear @s minecraft:diamond[!minecraft:custom_data] 9
give @s minecraft:diamond_block 1
execute if items entity @s container.* minecraft:diamond[!minecraft:custom_data,minecraft:count~{min:9}] run function enchantmentplus:enchantments/compressing/diamond
execute at @s run playsound enchantmentplus:enchant.compressing.compress player @s
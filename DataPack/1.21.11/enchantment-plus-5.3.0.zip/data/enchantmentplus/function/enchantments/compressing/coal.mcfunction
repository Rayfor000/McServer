execute unless items entity @s container.* minecraft:coal[!minecraft:custom_data,minecraft:count~{min:9}] run return fail
clear @s minecraft:coal[!minecraft:custom_data] 9
give @s minecraft:coal_block 1
execute if items entity @s container.* minecraft:coal[!minecraft:custom_data,minecraft:count~{min:9}] run function enchantmentplus:enchantments/compressing/coal
execute at @s run playsound enchantmentplus:enchant.compressing.compress player @s
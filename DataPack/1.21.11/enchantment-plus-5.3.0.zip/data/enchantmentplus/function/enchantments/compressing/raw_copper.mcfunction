execute unless items entity @s container.* minecraft:raw_copper[!minecraft:custom_data,minecraft:count~{min:9}] run return fail
clear @s minecraft:raw_copper[!minecraft:custom_data] 9
give @s minecraft:raw_copper_block 1
execute if items entity @s container.* minecraft:raw_copper[!minecraft:custom_data,minecraft:count~{min:9}] run function enchantmentplus:enchantments/compressing/raw_copper
execute at @s run playsound enchantmentplus:enchant.compressing.compress player @s
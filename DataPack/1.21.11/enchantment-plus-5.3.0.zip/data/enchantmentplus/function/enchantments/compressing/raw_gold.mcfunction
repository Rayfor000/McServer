execute unless items entity @s container.* minecraft:raw_gold[!minecraft:custom_data,minecraft:count~{min:9}] run return fail
clear @s minecraft:raw_gold[!minecraft:custom_data] 9
give @s minecraft:raw_gold_block 1
execute if items entity @s container.* minecraft:raw_gold[!minecraft:custom_data,minecraft:count~{min:9}] run function enchantmentplus:enchantments/compressing/raw_gold
execute at @s run playsound enchantmentplus:enchant.compressing.compress player @s
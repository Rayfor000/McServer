execute unless items entity @s container.* minecraft:gold_nugget[!minecraft:custom_data,minecraft:count~{min:9}] run return fail
clear @s minecraft:gold_nugget[!minecraft:custom_data] 9
give @s minecraft:gold_ingot 1
execute if items entity @s container.* minecraft:gold_nugget[!minecraft:custom_data,minecraft:count~{min:9}] run function enchantmentplus:enchantments/compressing/gold_nugget
execute at @s run playsound enchantmentplus:enchant.compressing.compress player @s
execute unless items entity @s container.* minecraft:gold_ingot[!minecraft:custom_data,minecraft:count~{min:9}] run return fail
clear @s minecraft:gold_ingot[!minecraft:custom_data] 9
give @s minecraft:gold_block 1
execute if items entity @s container.* minecraft:gold_ingot[!minecraft:custom_data,minecraft:count~{min:9}] run function enchantmentplus:enchantments/compressing/gold_nugget
execute at @s run playsound enchantmentplus:enchant.compressing.compress player @s
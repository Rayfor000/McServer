scoreboard players remove @s eplus.temp 1
particle minecraft:end_rod ~ ~ ~ 0.0 0.0 0.0 0 1 force
playsound enchantmentplus:enchant.divine_hunter.shoot player @a
execute as @e[type=#enchantmentplus:is_mob_or_player,tag=!eplus.divine_hunter_user,tag=!eplus.divine_hunter_exclude,dx=0] positioned ~-0.4 ~-0.4 ~-0.4 if entity @s[dx=0] run function enchantmentplus:enchantments/divine_hunter/hit_target
execute positioned ^ ^ ^0.125 if score @s eplus.temp matches 1.. run function enchantmentplus:enchantments/divine_hunter/run_raycast
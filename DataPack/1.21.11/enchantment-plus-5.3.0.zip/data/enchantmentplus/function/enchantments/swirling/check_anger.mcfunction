scoreboard players reset %Success eplus.temp
execute on target store success score %Success eplus.temp if entity @s[tag=eplus.swirling_user]
execute if score %Success eplus.temp matches 1 run tag @s add eplus.swirling_angry_at
playsound enchantmentplus:enchant.swirling.hit player @a
function enchantmentplus:enchantments/swirling/particles
execute as @p[tag=eplus.swirling_user] run function enchantmentplus:enchantments/swirling/base_damage
execute as @e[type=#enchantmentplus:is_neutral,distance=..5] run function enchantmentplus:enchantments/swirling/check_anger
execute as @e[type=#enchantmentplus:is_neutral,tag=eplus.swirling_angry_at,distance=..5] run function enchantmentplus:enchantments/swirling/cleave
tag @e[type=#enchantmentplus:is_neutral,tag=eplus.swirling_angry_at,distance=..5] remove eplus.swirling_angry_at
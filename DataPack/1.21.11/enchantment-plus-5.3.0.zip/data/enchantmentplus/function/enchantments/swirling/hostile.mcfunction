playsound enchantmentplus:enchant.swirling.hit player @a
function enchantmentplus:enchantments/swirling/particles
execute as @p[tag=eplus.swirling_user] run function enchantmentplus:enchantments/swirling/base_damage
execute as @e[type=#enchantmentplus:is_hostile,distance=..5] run function enchantmentplus:enchantments/swirling/cleave
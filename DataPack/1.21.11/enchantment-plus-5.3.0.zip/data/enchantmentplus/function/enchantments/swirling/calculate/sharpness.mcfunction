execute store result score %EnchantmentLevel eplus.temp run data get entity @s SelectedItem.components."minecraft:enchantments"."minecraft:sharpness" 5
scoreboard players add %EnchantmentLevel eplus.temp 5
scoreboard players operation @s eplus.swirling_damage += %EnchantmentLevel eplus.temp
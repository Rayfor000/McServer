playsound enchantmentplus:enchant.necrotic_ward.ward player @a
execute anchored eyes positioned ^ ^ ^ run particle minecraft:wax_off ~ ~ ~ 0.5 0.5 0.5 0 15 normal
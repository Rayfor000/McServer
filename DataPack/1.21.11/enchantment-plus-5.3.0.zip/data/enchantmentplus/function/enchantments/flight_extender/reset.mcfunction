scoreboard players reset @s eplus.flight_extender_used
advancement revoke @s only enchantmentplus:enchantments/flight_extender
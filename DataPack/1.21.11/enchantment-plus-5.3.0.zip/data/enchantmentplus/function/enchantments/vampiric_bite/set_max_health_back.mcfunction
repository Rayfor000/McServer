attribute @s minecraft:max_health modifier remove enchantmentplus:vampiric_bite_healed
tag @s remove eplus.vampiric_bite_healed
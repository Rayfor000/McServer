function enchantmentplus:enchantments/soul_enriching/enrich with storage enchantmentplus:data Macros
scoreboard players remove @s eplus.soul_stacks 5
playsound minecraft:block.sculk.spread player @a
particle minecraft:soul ~ ~ ~ 0.5 0.5 0.5 0 20 normal
title @s actionbar [{translate:"notification.enchantmentplus.souls_gathered",color:"dark_purple",fallback:"Souls Gathered: "},{score:{name:"@s",objective:"eplus.soul_stacks"},color:"gold"},{text:" | ",color:"gray"},{score:{name:"@s",objective:"eplus.max_soul_stacks"},color:"gray"}]
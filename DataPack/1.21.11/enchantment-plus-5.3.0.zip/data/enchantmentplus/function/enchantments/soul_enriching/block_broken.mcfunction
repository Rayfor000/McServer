data modify storage enchantmentplus:data Macros.SoulEnrichingBlockId set from entity @s data.SoulEnrichingBlockId
$execute as @p[nbt={UUID:$(UserUUID)}] run function enchantmentplus:enchantments/soul_enriching/check_soul
kill @s
$setblock ~ ~ ~ $(SoulEnrichingBlockId) strict
loot spawn ~ ~ ~ mine ~ ~ ~ mainhand
loot spawn ~ ~ ~ mine ~ ~ ~ mainhand
setblock ~ ~ ~ minecraft:air strict
advancement revoke @s only enchantmentplus:enchantments/soul_reserve
scoreboard players set @s eplus.max_soul_stacks 5
execute store result score %EnchantmentLevel eplus.temp run data get entity @s equipment.chest.components."minecraft:enchantments"."enchantmentplus:soul_reserve" 5
scoreboard players operation @s eplus.max_soul_stacks += %EnchantmentLevel eplus.temp
execute if score @s eplus.soul_stacks > @s eplus.max_soul_stacks run scoreboard players operation @s eplus.soul_stacks = @s eplus.max_soul_stacks
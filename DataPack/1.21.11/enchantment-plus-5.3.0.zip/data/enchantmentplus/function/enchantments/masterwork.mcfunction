advancement revoke @s only enchantmentplus:enchantments/masterwork
playsound enchantmentplus:masterwork_obtained player @s
tellraw @s {"translate":"enchantmentplus.128CNHUa1Uv","fallback":"You got lucky while enchanting and obtained a special enchanted book!","color":"green"}
loot give @s loot enchantmentplus:masterwork_book
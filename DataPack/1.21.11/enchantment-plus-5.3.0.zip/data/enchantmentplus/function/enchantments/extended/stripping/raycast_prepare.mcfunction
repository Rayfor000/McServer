advancement revoke @s only enchantmentplus:enchantments/extended/stripping
execute anchored eyes positioned ^ ^ ^ run function enchantmentplus:enchantments/extended/stripping/raycast_repeat
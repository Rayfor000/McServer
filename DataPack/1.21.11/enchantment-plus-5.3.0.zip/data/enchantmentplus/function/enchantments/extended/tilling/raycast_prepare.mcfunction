advancement revoke @s only enchantmentplus:enchantments/extended/tilling
execute anchored eyes positioned ^ ^ ^ run function enchantmentplus:enchantments/extended/tilling/raycast_repeat
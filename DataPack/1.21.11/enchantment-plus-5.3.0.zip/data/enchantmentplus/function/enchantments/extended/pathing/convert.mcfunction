setblock ~ ~ ~ minecraft:dirt_path
execute if predicate enchantmentplus:damage_chance run function enchantmentplus:damage_item/mainhand/get_value
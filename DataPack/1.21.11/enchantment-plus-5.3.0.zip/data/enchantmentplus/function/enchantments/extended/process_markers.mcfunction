scoreboard players add @s eplus.temp 1
execute if score @s eplus.temp matches 200.. run return run kill @s
execute if block ~ ~ ~ #minecraft:air run function enchantmentplus:enchantments/extended/block_broken with entity @s data
$execute unless block ~ ~ ~ $(ExtendedBlockId) run return run kill @s
execute if entity @e[type=minecraft:marker,tag=eplus.ex_marker] run schedule function enchantmentplus:enchantments/extended/schedule 1t
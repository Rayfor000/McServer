tag @s add eplus.ex_break
$execute as @p[nbt={UUID:$(UserUUID)}] run function enchantmentplus:enchantments/extended/mining/main
execute if score @s eplus.temp2 matches 1.. run function enchantmentplus:enchantments/extended/experience/summon_orb
kill @s
$execute positioned ~$(PosX) ~$(PosY) ~ if block ~ ~ ~ #enchantmentplus:extended/is_strippable if predicate enchantmentplus:break_safety run function enchantmentplus:enchantments/extended/stripping/convert
execute if score %PosX eplus.temp matches 0.. run scoreboard players remove %PosX eplus.temp 1
execute unless score %PosX eplus.temp matches 0.. run scoreboard players remove %PosY eplus.temp 1
execute unless score %PosX eplus.temp matches 0.. store result score %PosX eplus.temp run data get entity @s SelectedItem.components."minecraft:enchantments"."enchantmentplus:extended" 2
execute store result storage enchantmentplus:data Macros.Extended.PosX int 1 run scoreboard players get %PosX eplus.temp
execute store result storage enchantmentplus:data Macros.Extended.PosY int 1 run scoreboard players get %PosY eplus.temp
execute if score %PosX eplus.temp matches 0.. if score %PosY eplus.temp matches 0.. if predicate enchantmentplus:break_safety run function enchantmentplus:enchantments/extended/stripping/axis_z with storage enchantmentplus:data Macros.Extended{}
advancement revoke @s only enchantmentplus:enchantments/extended/pathing
execute anchored eyes positioned ^ ^ ^ run function enchantmentplus:enchantments/extended/pathing/raycast_repeat
scoreboard players add @s eplus.temp 1
execute if score @s eplus.temp matches 200.. run return run kill @s
execute if block ~ ~ ~ #minecraft:air run function enchantmentplus:enchantments/earthly_gatherer/block_broken with entity @s data
$execute unless block ~ ~ ~ $(EarthlyGathererBlockId) run return run kill @s
execute if entity @e[type=minecraft:marker,tag=eplus.eg_marker] run schedule function enchantmentplus:enchantments/earthly_gatherer/schedule 1t
data modify entity @s data.Motion set from entity @s Motion
tp @s @n[type=minecraft:marker,tag=eplus.eg_marker,tag=eplus.eg_break]
data modify entity @s Motion set from entity @s data.Motion
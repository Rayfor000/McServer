tag @s add eplus.eg_break
data modify storage enchantmentplus:data Macros.EarthlyGathererBlockId set from entity @s data.EarthlyGathererBlockId
$execute as @p[nbt={UUID:$(UserUUID)}] run function enchantmentplus:enchantments/earthly_gatherer/check_adjacent with storage enchantmentplus:data Macros
kill @s
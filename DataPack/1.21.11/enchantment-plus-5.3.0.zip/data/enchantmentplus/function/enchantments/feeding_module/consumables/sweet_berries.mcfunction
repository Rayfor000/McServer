effect give @s minecraft:saturation 1 1 true
clear @s minecraft:sweet_berries 1
playsound minecraft:entity.generic.eat player @a
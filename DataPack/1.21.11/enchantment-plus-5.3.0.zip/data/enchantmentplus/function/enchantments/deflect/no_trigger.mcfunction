scoreboard players reset @s eplus.deflect_damage_resisted
advancement revoke @s only enchantmentplus:enchantments/deflect/no_trigger
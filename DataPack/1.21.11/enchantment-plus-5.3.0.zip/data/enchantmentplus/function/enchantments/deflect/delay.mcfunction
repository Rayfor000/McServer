execute if score @s eplus.deflect_delay matches 1.. run scoreboard players remove @s eplus.deflect_delay 1
execute if score @s eplus.deflect_delay matches 0 run title @s actionbar {"translate":"enchantmentplus.aQBV2FpmnL2","fallback":"\u00A7ADeflect is ready!"}
execute if score @s eplus.deflect_delay matches 0 run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 2
execute if score @s eplus.deflect_delay matches 1.. run advancement revoke @s only enchantmentplus:enchantments/deflect/delay
execute if entity @s[advancements={gm4_guidebook:ziprails/unlock/description=true}] run function gm4_guidebook:ziprails/rewards/unlock/description
return 1

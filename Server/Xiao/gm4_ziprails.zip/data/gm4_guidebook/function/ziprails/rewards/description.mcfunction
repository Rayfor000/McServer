tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Ziprails]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Ziprails",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.ziprails",fallback:"Automatically latch on to a tripwire to sail through the sky on a suspended line!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:ziprails/display/description
function gm4_guidebook:ziprails/rewards/unlock/description

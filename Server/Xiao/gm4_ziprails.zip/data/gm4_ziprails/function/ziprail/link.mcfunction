tag @s add gm4_linked
tag @s remove gm4_zipping_north
tag @s remove gm4_zipping_south
tag @s remove gm4_zipping_east
tag @s remove gm4_zipping_west
execute if block ~ ~1 ~ tripwire_hook[facing=north] run tag @s add gm4_zipping_north
execute if block ~ ~1 ~ tripwire_hook[facing=south] run tag @s add gm4_zipping_south
execute if block ~ ~1 ~ tripwire_hook[facing=east] run tag @s add gm4_zipping_east
execute if block ~ ~1 ~ tripwire_hook[facing=west] run tag @s add gm4_zipping_west
playsound minecraft:entity.item_frame.place neutral @p[distance=..1, limit=1]

execute if entity @s[tag=!gm4_linked] if block ~ ~1 ~ tripwire_hook[attached=true] run function gm4_ziprails:ziprail/link
execute if entity @s[tag=!gm4_taut_link, tag=gm4_linked] unless block ~ ~ ~ #minecraft:rails align y run teleport @s ~ ~0.36250001192093 ~
execute if entity @s[tag=gm4_linked] unless block ~ ~ ~ #minecraft:rails run tag @s add gm4_taut_link
execute if block ~ ~ ~ #minecraft:rails run tag @s remove gm4_taut_link
execute if entity @s[tag=!gm4_taut_link] if block ~ ~1 ~ tripwire_hook[attached=true] run function gm4_ziprails:ziprail/link
data merge entity @s[tag=gm4_taut_link, tag=gm4_zipping_north] {"Motion":[0.0,0.06,-0.4]}
data merge entity @s[tag=gm4_taut_link, tag=gm4_zipping_south] {"Motion":[0.0,0.06,0.4]}
data merge entity @s[tag=gm4_taut_link, tag=gm4_zipping_east] {"Motion":[0.4,0.06,0.0]}
data merge entity @s[tag=gm4_taut_link, tag=gm4_zipping_west] {"Motion":[-0.4,0.06,0.0]}

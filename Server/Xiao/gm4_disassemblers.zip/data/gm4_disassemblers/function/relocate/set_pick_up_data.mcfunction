data modify storage gm4_relocators:temp merge_data set value {"custom_block":"gm4_disassembler","lore":{"translate":"gm4_disassemblers.7Ogq1GDV9zt","fallback":"Disassembler","color":"gray","italic":true}}
data modify storage gm4_relocators:temp merge_data.entity_data.Rotation set from entity @s Rotation
data modify storage gm4_relocators:temp merge_data.entity_data.equipment set from entity @e[type=armor_stand, tag=gm4_disassembler_stand, distance=..0.5, limit=1] equipment
execute positioned ~ ~-0.4 ~ run kill @e[type=armor_stand, tag=gm4_disassembler_stand, limit=1, distance=..0.01]
kill @s
scoreboard players set $found_marker gm4_rl_data 1

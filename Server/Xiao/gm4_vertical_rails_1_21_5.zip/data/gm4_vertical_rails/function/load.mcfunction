execute if score gm4 load.status matches 1 if score gm4_minor load.status matches 8.. run scoreboard players set gm4_vertical_rails load.status 1
execute if score gm4 load.status matches 1 if score gm4_minor load.status matches 8.. run scoreboard players set gm4_vertical_rails_minor load.status 6
execute unless score gm4 load.status matches 1.. run data modify storage gm4:log queue append value {type:"missing",module:"Vertical Rails",id:"gm4_vertical_rails",require:"Gamemode 4 Base",require_id:"gm4"}
execute if score gm4 load.status matches 1.. unless score gm4 load.status matches 1 run data modify storage gm4:log queue append value {type:"version_conflict",module:"Vertical Rails",id:"gm4_vertical_rails",require:"Gamemode 4 Base",require_id:"gm4",require_ver:"1.8.0"}
execute if score gm4 load.status matches 1 unless score gm4_minor load.status matches 8.. run data modify storage gm4:log queue append value {type:"version_conflict",module:"Vertical Rails",id:"gm4_vertical_rails",require:"Gamemode 4 Base",require_id:"gm4",require_ver:"1.8.0"}
execute unless score gm4_vertical_rails load.status matches 1.. run scoreboard players set gm4_vertical_rails load.status -1
execute if score gm4_vertical_rails load.status matches 1 run function gm4_vertical_rails:init
execute unless score gm4_vertical_rails load.status matches 1 run schedule clear gm4_vertical_rails:main
execute unless score gm4_vertical_rails load.status matches 1 run schedule clear gm4_vertical_rails:tick

execute if entity @s[advancements={gm4_guidebook:xp_storage/unlock/description=true}] run function gm4_guidebook:xp_storage/rewards/unlock/description
return 1

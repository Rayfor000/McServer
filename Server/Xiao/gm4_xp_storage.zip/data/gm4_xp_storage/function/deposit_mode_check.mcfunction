scoreboard players set $played_sound gm4_xp_data 0
execute if entity @s[predicate=gm4_xp_storage:sneaking] run scoreboard players set xp_dump_all_counter gm4_xp_calc 1
execute if entity @s[predicate=gm4_xp_storage:sneaking, level=1..] run function gm4_xp_storage:dump_all
execute if entity @s[predicate=!gm4_xp_storage:sneaking, level=1..] run function gm4_xp_storage:dump_level

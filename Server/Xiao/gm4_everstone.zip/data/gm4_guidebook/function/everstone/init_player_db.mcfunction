execute if entity @s[advancements={gm4_guidebook:everstone/unlock/obtaining=true}] run function gm4_guidebook:everstone/rewards/unlock/obtaining
execute if entity @s[advancements={gm4_guidebook:everstone/unlock/usage=true}] run function gm4_guidebook:everstone/rewards/unlock/usage
execute if entity @s[advancements={gm4_guidebook:everstone/unlock/zombie_conversion=true}] run function gm4_guidebook:everstone/rewards/unlock/zombie_conversion
execute if entity @s[advancements={gm4_guidebook:everstone/unlock/skeleton_conversion=true}] run function gm4_guidebook:everstone/rewards/unlock/skeleton_conversion
execute if entity @s[advancements={gm4_guidebook:everstone/unlock/slime_conversion=true}] run function gm4_guidebook:everstone/rewards/unlock/slime_conversion
execute if entity @s[advancements={gm4_guidebook:everstone/unlock/stray_conversion=true}] run function gm4_guidebook:everstone/rewards/unlock/stray_conversion
execute if entity @s[advancements={gm4_guidebook:everstone/unlock/piglin_conversion=true}] run function gm4_guidebook:everstone/rewards/unlock/piglin_conversion
execute if entity @s[advancements={gm4_guidebook:everstone/unlock/guardian_conversion=true}] run function gm4_guidebook:everstone/rewards/unlock/guardian_conversion
execute if entity @s[advancements={gm4_guidebook:everstone/unlock/vindicator_conversion=true}] run function gm4_guidebook:everstone/rewards/unlock/vindicator_conversion
return 1

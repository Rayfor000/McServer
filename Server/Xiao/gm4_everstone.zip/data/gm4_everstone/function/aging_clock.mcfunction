schedule function gm4_everstone:aging_clock 30s
execute store result score $age_count gm4_es_data if entity @e[type=#gm4_everstone:aging_mob, tag=!gm4_everstone_locked, tag=!gm4_everstone_ignore, tag=!smithed.entity, limit=1000]
scoreboard players operation $age_count gm4_es_data *= #chance gm4_es_data
execute if score $age_count gm4_es_data matches 1.. run function gm4_everstone:aging/age_mobs

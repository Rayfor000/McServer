execute if score $age_count gm4_es_data matches 1..99 run function gm4_everstone:aging/single
execute if score $age_count gm4_es_data matches 100.. run function gm4_everstone:aging/multiple

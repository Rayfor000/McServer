scoreboard players add @s[predicate=gm4_everstone:in_frozen_sunlight] gm4_es_age 1
scoreboard players remove @s[predicate=!gm4_everstone:in_frozen_sunlight, scores={gm4_es_age=1..}] gm4_es_age 1
execute if score @s gm4_es_age matches 6.. run function gm4_everstone:aging/convert/stray
scoreboard players add @s[predicate=gm4_everstone:in_swampy_water] gm4_es_age_alt 1
scoreboard players remove @s[predicate=!gm4_everstone:in_swamp, scores={gm4_es_age_alt=1..}] gm4_es_age_alt 1
execute if score @s gm4_es_age_alt matches 12.. run function gm4_everstone:aging/convert/bogged

execute store result score @s gm4_es_data if entity @e[type=piglin_brute, distance=..32]
scoreboard players add @s[predicate=gm4_everstone:in_bastion_remnant, scores={gm4_es_data=..2}] gm4_es_age 1
scoreboard players remove @s[predicate=!gm4_everstone:in_bastion_remnant, scores={gm4_es_age=1..}] gm4_es_age 1
execute if score @s gm4_es_age matches 12.. run function gm4_everstone:aging/convert/piglin_brute

execute unless block ~ ~0.5 ~ water run scoreboard players add @s[predicate=gm4_everstone:in_dry_sunlight] gm4_es_age 1
scoreboard players remove @s[predicate=!gm4_everstone:in_dry_sunlight, scores={gm4_es_age=1..}] gm4_es_age 1
execute if score @s gm4_es_age matches 6.. run function gm4_everstone:aging/convert/husk

execute store result score @s gm4_es_data run clone ~-2 ~-1 ~-2 ~2 ~2 ~2 ~-2 ~-1 ~-2 filtered #gm4_everstone:contains_magic force
scoreboard players add @s[scores={gm4_es_data=7..}] gm4_es_age 1
scoreboard players remove @s[scores={gm4_es_data=0}] gm4_es_age 1
execute if score @s gm4_es_age matches 12.. run function gm4_everstone:aging/convert/evoker

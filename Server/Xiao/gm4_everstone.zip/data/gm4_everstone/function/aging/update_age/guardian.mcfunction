execute store result score @s gm4_es_data if entity @e[type=guardian, distance=..8, tag=!gm4_everstone_locked]
execute unless entity @e[type=elder_guardian, distance=..32, limit=1] run scoreboard players add @s[scores={gm4_es_data=6..}] gm4_es_age 1
execute if score @s gm4_es_age matches 24.. run function gm4_everstone:aging/convert/elder_guardian

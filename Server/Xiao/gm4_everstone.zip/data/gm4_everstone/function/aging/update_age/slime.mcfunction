scoreboard players add @s[predicate=gm4_everstone:in_nether] gm4_es_age 1
scoreboard players remove @s[predicate=!gm4_everstone:in_nether, scores={gm4_es_age=1..}] gm4_es_age 1
execute if score @s gm4_es_age matches 6.. run function gm4_everstone:aging/convert/magma_cube

scoreboard players add @s[predicate=gm4_everstone:sheared_and_out_of_swamp] gm4_es_age 1
scoreboard players remove @s[predicate=gm4_everstone:in_swamp, scores={gm4_es_age=1..}] gm4_es_age 1
execute if score @s gm4_es_age matches 12.. run function gm4_everstone:aging/convert/skeleton

data merge storage gm4:log {"queue":[],"versions":[]}
data modify storage gm4:log queue append value {"type":"text","message":{"color":"#4AA0C7","translate":"gm4-1.8.jNVWiSaH2Fs","fallback":"[GM4]: Checking for updates..."}}
scoreboard objectives add gm4_modules dummy
scoreboard objectives add gm4_data dummy
function gm4-1.8:upgrade_paths/load
scoreboard objectives add gm4_creative dummy
execute unless score $global gm4_creative matches 0.. run scoreboard players set $global gm4_creative 10
execute unless score $cooldown gm4_creative matches 0.. run scoreboard players set $cooldown gm4_creative 10
execute unless score $global_cooldown gm4_creative matches 0.. run scoreboard players set $global_cooldown gm4_creative 10
execute unless score gm4 gm4_modules matches 1.. run data modify storage gm4:log queue append value {"type":"text","message":{"color":"green","translate":"gm4-1.8.6SZEJQv5M3b","fallback":"[GM4]: Welcome to Gamemode 4. Initialising..."}}
execute unless score gm4 gm4_modules matches 1.. run schedule function gm4-1.8:intro_song/init 2s
execute unless score gm4 gm4_modules matches 1.. run scoreboard players set gm4 gm4_modules 1

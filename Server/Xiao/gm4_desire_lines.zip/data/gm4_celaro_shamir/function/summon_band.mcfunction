loot spawn ~ ~ ~ loot gm4_celaro_shamir:band

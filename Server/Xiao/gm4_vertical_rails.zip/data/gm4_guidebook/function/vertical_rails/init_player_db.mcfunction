execute if entity @s[advancements={gm4_guidebook:vertical_rails/unlock/description=true}] run function gm4_guidebook:vertical_rails/rewards/unlock/description
return 1

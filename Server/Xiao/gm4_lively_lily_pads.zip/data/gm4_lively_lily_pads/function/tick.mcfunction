schedule function gm4_lively_lily_pads:tick 8
execute as @e[type=block_display, tag=gm4_llp_light] at @s run function gm4_lively_lily_pads:mechanics/particles/select_type

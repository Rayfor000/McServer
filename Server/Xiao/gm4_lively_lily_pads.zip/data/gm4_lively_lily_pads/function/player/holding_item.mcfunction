tag @s add gm4_llp_holding_item
scoreboard players set $ray gm4_llp.data 12
execute anchored eyes positioned ^ ^ ^ run function gm4_lively_lily_pads:mechanics/right_click_detection/ray

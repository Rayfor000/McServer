tag @e[type=interaction, tag=gm4_llp_candle_rcd, tag=!gm4_llp_perma_rcd] add gm4_llp_perma_rcd

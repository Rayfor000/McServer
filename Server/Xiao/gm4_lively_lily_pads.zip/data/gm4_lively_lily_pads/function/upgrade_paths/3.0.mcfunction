kill @e[type=minecraft:interaction, tag=lilyPadInt]
kill @e[type=minecraft:block_display, tag=lilyPadLight2]
execute as @e[type=minecraft:block_display, tag=lilyPadLight] at @s align xyz positioned ~0.5 ~0.02 ~0.5 run function gm4_lively_lily_pads:upgrade_paths/3.0/update_legacy_display

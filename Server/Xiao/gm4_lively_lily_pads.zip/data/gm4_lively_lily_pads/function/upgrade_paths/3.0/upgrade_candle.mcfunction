function gm4_lively_lily_pads:mechanics/interactions/placement/candles with storage gm4_llp:temp
data modify entity @e[type=minecraft:block_display, tag=gm4_llp_candle, limit=1, distance=..0.1] block_state.Properties.candles set from entity @s block_state.Properties.candles
data modify entity @e[type=minecraft:block_display, tag=gm4_llp_candle, limit=1, distance=..0.1] block_state.Properties.lit set from entity @s block_state.Properties.lit
execute if data entity @s {block_state:{Properties:{lit:"true"}}} run tag @e[type=minecraft:block_display, tag=gm4_llp_candle, limit=1, distance=..0.1] add gm4_llp_lit_candle

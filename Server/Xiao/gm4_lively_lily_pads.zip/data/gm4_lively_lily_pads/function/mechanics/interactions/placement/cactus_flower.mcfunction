summon minecraft:block_display ~ ~ ~ {"Tags":["gm4_llp_display","gm4_llp_cactus_flower_sound","smithed.entity"],"block_state":{"Name":"minecraft:cactus_flower"},"transformation":{"scale":[0.8,0.8,0.8],"translation":[-0.4,0.0,-0.4],"left_rotation":[0.0,0.0,0.0,1.0],"right_rotation":[0.0,0.0,0.0,1.0]}}
playsound minecraft:block.cactus_flower.place block @a[distance=..16] ~ ~ ~

$summon minecraft:block_display ~ ~ ~ {Tags:["gm4_llp_display","gm4_llp_candle","gm4_llp_light","smithed.entity"],block_state:{Name:"$(DisplayType)",Properties:{candles:"1"}},transformation:{scale:[0.8f,0.8f,0.8f],translation:[-0.4f,0f,-0.4f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:interaction ~ ~ ~ {"width":0.4,"height":0.4,"response":1,"Tags":["gm4_llp_candle_rcd","gm4_llp_perma_rcd","smithed.entity","smithed.strict"]}
playsound minecraft:block.candle.place block @a[distance=..16] ~ ~ ~

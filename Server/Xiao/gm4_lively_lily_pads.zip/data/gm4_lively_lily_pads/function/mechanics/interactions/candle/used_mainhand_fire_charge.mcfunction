playsound minecraft:item.firecharge.use player @a[distance=..16]
execute if entity @s[gamemode=creative] run return 1
item modify entity @s weapon.mainhand {"function":"minecraft:set_count","count":-1,"add":1}

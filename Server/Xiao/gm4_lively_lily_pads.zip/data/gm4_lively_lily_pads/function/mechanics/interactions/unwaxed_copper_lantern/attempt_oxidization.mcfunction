execute store result score $rand gm4_llp.data run random value 1..6500
execute if score $rand gm4_llp.data matches 2.. run return fail
execute if data entity @s {block_state:{Name:"minecraft:copper_lantern"}} run return run data modify entity @s block_state.Name set value "minecraft:exposed_copper_lantern"
execute if data entity @s {block_state:{Name:"minecraft:exposed_copper_lantern"}} run return run data modify entity @s block_state.Name set value "minecraft:weathered_copper_lantern"
execute if data entity @s {block_state:{Name:"minecraft:weathered_copper_lantern"}} run return run data modify entity @s block_state.Name set value "minecraft:oxidized_copper_lantern"

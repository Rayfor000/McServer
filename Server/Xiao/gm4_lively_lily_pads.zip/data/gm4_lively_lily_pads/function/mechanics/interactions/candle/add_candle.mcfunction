execute store success score $different_candle gm4_llp.data run data modify storage gm4_llp:temp held_item set from entity @s block_state.Name
execute if score $different_candle gm4_llp.data matches 1 run return fail
execute if data entity @s {block_state:{Properties:{candles:"4"}}} run return 1
scoreboard players set $placement_success gm4_llp.data 1
playsound minecraft:block.candle.place block @a[distance=..16] ~ ~ ~
execute if data entity @s {block_state:{Properties:{candles:"3"}}} run data modify entity @s block_state.Properties.candles set value "4"
execute if data entity @s {block_state:{Properties:{candles:"2"}}} run data modify entity @s block_state.Properties.candles set value "3"
execute if data entity @s {block_state:{Properties:{candles:"1"}}} run data modify entity @s block_state.Properties.candles set value "2"
execute if entity @s[tag=gm4_llp_lit_candle] run function gm4_lively_lily_pads:mechanics/interactions/candle/update_light_blocks
return 1

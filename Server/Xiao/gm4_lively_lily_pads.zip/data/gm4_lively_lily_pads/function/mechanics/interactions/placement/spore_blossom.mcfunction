summon minecraft:block_display ~ ~ ~ {"Tags":["gm4_llp_display","gm4_llp_spore_blossom_sound","smithed.entity"],"block_state":{"Name":"minecraft:spore_blossom"},"transformation":{"scale":[0.5,0.5,0.7],"translation":[-0.25,0.7,0.25],"left_rotation":[0.707,0.0,0.0,0.707],"right_rotation":[0.707,0.0,0.0,0.707]}}
playsound minecraft:block.spore_blossom.place block @a[distance=..16] ~ ~ ~

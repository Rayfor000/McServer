summon minecraft:block_display ~ ~ ~ {"Tags":["gm4_llp_display","gm4_llp_light","gm4_llp_light.9","gm4_llp_lantern_sound","smithed.entity"],"block_state":{"Name":"minecraft:soul_lantern"},"transformation":{"scale":[0.8,0.8,0.8],"translation":[-0.4,0.0,-0.4],"left_rotation":[0.0,0.0,0.0,1.0],"right_rotation":[0.0,0.0,0.0,1.0]}}
setblock ~ ~1 ~ light[level=9] keep
playsound minecraft:block.lantern.place block @a[distance=..16] ~ ~ ~

advancement revoke @s only gm4_lively_lily_pads:waxed_copper_rcd
scoreboard players set $mainhand gm4_llp.data 0
scoreboard players set $offhand gm4_llp.data 0
scoreboard players set $holding_axe gm4_llp.data 0
scoreboard players set $scraped gm4_llp.data 0
execute if items entity @s weapon.mainhand #minecraft:axes store success score $holding_axe gm4_llp.data run scoreboard players set $mainhand gm4_llp.data 1
execute unless score $mainhand gm4_llp.data matches 1 if items entity @s weapon.offhand #minecraft:axes store success score $holding_axe gm4_llp.data run scoreboard players set $offhand gm4_llp.data 1
execute as @e[type=interaction, tag=gm4_llp_waxed_copper_rcd, distance=..8] if data entity @s interaction at @s run function gm4_lively_lily_pads:mechanics/interactions/waxed_copper_lantern/process_interaction
execute if score $scraped gm4_llp.data matches 0 run return fail
execute if score $mainhand gm4_llp.data matches 1 if entity @s[gamemode=!creative] run function gm4_lively_lily_pads:mechanics/interactions/waxed_copper_lantern/used_mainhand_axe
execute if score $offhand gm4_llp.data matches 1 if entity @s[gamemode=!creative] run function gm4_lively_lily_pads:mechanics/interactions/waxed_copper_lantern/used_offhand_axe

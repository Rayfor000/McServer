summon minecraft:block_display ~ ~ ~ {"Tags":["gm4_llp_display","gm4_llp_light","gm4_llp_light.14","gm4_llp_wood_sound","gm4_llp_smoke_torch","smithed.entity"],"block_state":{"Name":"minecraft:copper_torch"},"transformation":{"scale":[0.8,0.8,0.8],"translation":[-0.4,0.0,-0.4],"left_rotation":[0.0,0.0,0.0,1.0],"right_rotation":[0.0,0.0,0.0,1.0]}}
setblock ~ ~1 ~ light[level=14] keep
playsound minecraft:block.wood.place block @a[distance=..16] ~ ~ ~

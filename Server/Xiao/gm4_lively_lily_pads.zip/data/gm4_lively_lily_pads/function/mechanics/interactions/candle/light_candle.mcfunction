execute store success score $ignited gm4_llp.data run data modify entity @s block_state.Properties.lit set value "true"
execute if score $ignited gm4_llp.data matches 0 run return fail
tag @s add gm4_llp_lit_candle
function gm4_lively_lily_pads:mechanics/interactions/candle/update_light_blocks
return 1

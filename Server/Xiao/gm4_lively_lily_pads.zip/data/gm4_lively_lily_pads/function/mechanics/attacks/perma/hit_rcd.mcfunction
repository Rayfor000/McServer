advancement revoke @s only gm4_lively_lily_pads:punch_perma_rcd
execute if entity @s[gamemode=creative] run scoreboard players set $creative gm4_llp.data 1
execute as @e[type=interaction, tag=gm4_llp_perma_rcd, distance=..8] if data entity @s attack at @s run function gm4_lively_lily_pads:mechanics/attacks/perma/process_interaction

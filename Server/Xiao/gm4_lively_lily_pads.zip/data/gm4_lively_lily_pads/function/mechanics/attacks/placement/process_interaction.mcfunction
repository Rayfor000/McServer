execute store result score $gametime gm4_llp.data run time query gametime
execute store result score $check_gametime gm4_llp.data run data get entity @s attack.timestamp 1
data remove entity @s attack
execute unless score $gametime gm4_llp.data = $check_gametime gm4_llp.data run return fail
kill @s
execute unless score $creative gm4_llp.data matches 1 run return run setblock ~ ~ ~ air destroy
setblock ~ ~ ~ air
scoreboard players reset $creative gm4_llp.data
playsound minecraft:block.big_dripleaf.break block @a[distance=..16] ~ ~ ~

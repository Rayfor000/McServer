execute store result score $gametime gm4_llp.data run time query gametime
execute store result score $check_gametime gm4_llp.data run data get entity @s attack.timestamp 1
data remove entity @s attack
execute unless score $gametime gm4_llp.data = $check_gametime gm4_llp.data run return fail
execute align xyz as @e[type=block_display, tag=gm4_llp_display, dx=0, limit=1] at @s run function gm4_lively_lily_pads:mechanics/cleanup/kill
scoreboard players reset $creative gm4_llp.data

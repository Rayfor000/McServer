particle small_flame ~0.05 ~0.42 ~-0.05
particle small_flame ~-0.1 ~0.37 ~
particle small_flame ~ ~0.27 ~0.1
execute if score $rand gm4_llp.data matches 1 run particle smoke ~0.05 ~0.43 ~-0.05
execute if score $rand gm4_llp.data matches 2 run particle smoke ~-0.1 ~0.38 ~
execute if score $rand gm4_llp.data matches 3 run particle smoke ~ ~0.28 ~0.1

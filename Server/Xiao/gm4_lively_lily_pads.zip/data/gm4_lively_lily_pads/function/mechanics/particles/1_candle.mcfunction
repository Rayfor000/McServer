particle small_flame ~ ~0.42 ~
execute if score $rand gm4_llp.data matches 1 run particle smoke ~ ~0.43 ~

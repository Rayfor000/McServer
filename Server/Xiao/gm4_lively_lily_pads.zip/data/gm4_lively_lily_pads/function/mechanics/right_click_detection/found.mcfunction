particle scrape ~0.5 ~0.12 ~0.5 0 0 0 0 1
scoreboard players operation $player gm4_llp.id = @s gm4_llp.id
execute unless entity @e[type=interaction, tag=gm4_llp_placement_rcd, dx=0, limit=1] positioned ~0.5 ~0.02 ~0.5 summon minecraft:interaction run function gm4_lively_lily_pads:mechanics/right_click_detection/create
scoreboard players set $timer gm4_llp.data 10
function gm4_lively_lily_pads:mechanics/right_click_detection/loop

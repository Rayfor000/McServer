execute if block ~ ~0.5 ~ minecraft:lily_pad if block ~ ~ ~ minecraft:lily_pad align xyz unless entity @e[type=minecraft:block_display, limit=1, dx=0, tag=gm4_llp_display] run return run function gm4_lively_lily_pads:mechanics/right_click_detection/found
scoreboard players remove $ray gm4_llp.data 1
execute if score $ray gm4_llp.data matches 0.. positioned ^ ^ ^0.5 run function gm4_lively_lily_pads:mechanics/right_click_detection/ray

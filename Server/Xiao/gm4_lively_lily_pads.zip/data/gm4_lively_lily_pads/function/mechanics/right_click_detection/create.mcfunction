data merge entity @s {"width":0.4,"height":0.3,"response":1,"Tags":["gm4_llp_placement_rcd","smithed.entity","smithed.strict"]}
scoreboard players operation @s gm4_llp.id = $player gm4_llp.id

$summon minecraft:item ~ ~-.02 ~ {Item:{id:"$(id)",count:$(count)},Motion:$(motion)}

data modify storage gm4_balloon_animals:temp gm4_balloon_animals set value {"trade":1}
function gm4_balloon_animals:wandering_trader/trade/pick_animal
data modify storage gm4_balloon_animals:temp gm4_balloon_animals set value {"trade":2}
function gm4_balloon_animals:wandering_trader/trade/pick_animal

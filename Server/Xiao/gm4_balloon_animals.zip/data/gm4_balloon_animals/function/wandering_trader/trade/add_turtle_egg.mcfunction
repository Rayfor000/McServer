tp @s ~ 0 ~
data merge entity @s {"Silent":1,"NoGravity":1,"Invulnerable":1,"ChestedHorse":1,"Variant":0,"Strength":1,"DespawnDelay":1,"Tags":["gm4_trade_option"],"Items":[{"id":"minecraft:emerald","count":8,"Slot":1}],"equipment":{"body":{"id":"minecraft:light_blue_carpet","count":1,"components":{"minecraft:custom_data":{"gm4_trades":{"options":{"maxUses":1,"rewardXp":1,"xp":1,"priceMultiplier":0.05}}}}}}}
loot replace entity @s horse.0 loot gm4_balloon_animals:turtle_egg

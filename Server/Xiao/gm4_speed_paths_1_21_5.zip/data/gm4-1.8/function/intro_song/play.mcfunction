scoreboard players add @s gm4_intro_song 40
function gm4-1.8:intro_song/tree/0_127
scoreboard players set $song_playing gm4_intro_song 1

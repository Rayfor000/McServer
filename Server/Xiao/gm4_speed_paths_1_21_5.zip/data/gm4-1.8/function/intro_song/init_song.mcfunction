tag @s add gm4_intro_playing
scoreboard players set @s gm4_intro_song -240
scoreboard players set @s gm4_intro_song_t -1
schedule function gm4-1.8:intro_song/main 1t

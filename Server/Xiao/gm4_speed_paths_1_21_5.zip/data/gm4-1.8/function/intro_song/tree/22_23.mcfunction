execute if entity @s[scores={gm4_intro_song=1840..1960,gm4_intro_song_t=..22}] run function gm4-1.8:intro_song/notes/23

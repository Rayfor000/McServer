execute if score gm4 load.status matches 1 if score gm4_minor load.status matches 8 run function gm4-1.8:post_load

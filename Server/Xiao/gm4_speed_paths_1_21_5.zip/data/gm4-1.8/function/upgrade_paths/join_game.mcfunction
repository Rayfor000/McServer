advancement revoke @s only gm4-1.8:upgrade_paths/join_game
scoreboard players reset @s gm4_up_leave_game
tag @s add gm4_running_upgrade_path
function gm4-1.8:upgrade_paths/run_when_loaded

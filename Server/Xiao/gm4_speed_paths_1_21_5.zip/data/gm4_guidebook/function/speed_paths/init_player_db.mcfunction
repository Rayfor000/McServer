execute if entity @s[advancements={gm4_guidebook:speed_paths/unlock/description=true}] run function gm4_guidebook:speed_paths/rewards/unlock/description
return 1

execute store success score $dropped_item gm4_machine_data run loot spawn ~ ~ ~ loot gm4_ender_hoppers:entities/ender_hopper_minecart
particle explosion ~ ~ ~
kill @s

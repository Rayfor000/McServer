execute positioned ~ ~ ~ run kill @e[type=item_display, tag=gm4_ender_hopper_display, limit=1, distance=..0.01]
execute store result score $dropped_item gm4_machine_data run kill @e[type=item, distance=..1, nbt={Age:0s,Item:{id:"minecraft:hopper",count:1,components:{}}}, limit=1, sort=nearest]
kill @s
particle explosion ~ ~ ~
execute if score $dropped_item gm4_machine_data matches 1 run loot spawn ~ ~ ~ loot gm4_ender_hoppers:items/ender_hopper

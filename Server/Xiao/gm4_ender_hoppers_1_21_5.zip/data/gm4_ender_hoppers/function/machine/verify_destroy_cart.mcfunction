execute if entity @s[tag=gm4_ender_hopper_display] run function gm4_ender_hoppers:machine/destroy_cart

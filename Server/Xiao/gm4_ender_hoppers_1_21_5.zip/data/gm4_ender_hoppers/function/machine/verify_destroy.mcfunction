execute if entity @s[tag=gm4_ender_hopper] run function gm4_ender_hoppers:machine/destroy

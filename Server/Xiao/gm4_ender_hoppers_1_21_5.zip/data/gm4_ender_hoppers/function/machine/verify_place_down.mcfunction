execute if score $placed_block gm4_machine_data matches 0 if data storage gm4_machines:temp {id:"ender_hopper"} run function gm4_ender_hoppers:machine/create

execute if score gm4_ender_hoppers load.status matches 1.. if entity @s[tag=gm4_ender_hopper] run function gm4_ender_hoppers:relocate/set_pick_up_data

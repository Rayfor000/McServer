schedule function gm4_machines-1.4:main 16t
execute if entity @e[type=#gm4:minecarts,tag=!gm4_machine_checked,limit=1] run function gm4_machines-1.4:place_down/place_machine_cart

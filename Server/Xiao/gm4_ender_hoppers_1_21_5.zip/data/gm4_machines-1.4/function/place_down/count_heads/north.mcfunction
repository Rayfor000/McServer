execute store result score $player_head_add gm4_machine_data run clone ~-4 ~-4 ~-4 ~4 ~-4 ~1 ~-4 ~-4 ~-4 filtered #gm4_machines:player_heads{components:{"minecraft:custom_data":{gm4_machines:{}}}} force
scoreboard players operation $player_head_count gm4_machine_data += $player_head_add gm4_machine_data
execute store result score $player_head_add gm4_machine_data run clone ~-4 ~-3 ~-4 ~4 ~-3 ~1 ~-4 ~-3 ~-4 filtered #gm4_machines:player_heads{components:{"minecraft:custom_data":{gm4_machines:{}}}} force
scoreboard players operation $player_head_count gm4_machine_data += $player_head_add gm4_machine_data
execute store result score $player_head_add gm4_machine_data run clone ~-4 ~-2 ~-4 ~4 ~-2 ~1 ~-4 ~-2 ~-4 filtered #gm4_machines:player_heads{components:{"minecraft:custom_data":{gm4_machines:{}}}} force
scoreboard players operation $player_head_count gm4_machine_data += $player_head_add gm4_machine_data
execute store result score $player_head_add gm4_machine_data run clone ~-4 ~-1 ~-4 ~4 ~-1 ~1 ~-4 ~-1 ~-4 filtered #gm4_machines:player_heads{components:{"minecraft:custom_data":{gm4_machines:{}}}} force
scoreboard players operation $player_head_count gm4_machine_data += $player_head_add gm4_machine_data
execute store result score $player_head_add gm4_machine_data run clone ~-4 ~ ~-4 ~4 ~ ~1 ~-4 ~ ~-4 filtered #gm4_machines:player_heads{components:{"minecraft:custom_data":{gm4_machines:{}}}} force
scoreboard players operation $player_head_count gm4_machine_data += $player_head_add gm4_machine_data
execute store result score $player_head_add gm4_machine_data run clone ~-4 ~1 ~-4 ~4 ~1 ~1 ~-4 ~1 ~-4 filtered #gm4_machines:player_heads{components:{"minecraft:custom_data":{gm4_machines:{}}}} force
scoreboard players operation $player_head_count gm4_machine_data += $player_head_add gm4_machine_data
execute store result score $player_head_add gm4_machine_data run clone ~-4 ~2 ~-4 ~4 ~2 ~1 ~-4 ~2 ~-4 filtered #gm4_machines:player_heads{components:{"minecraft:custom_data":{gm4_machines:{}}}} force
scoreboard players operation $player_head_count gm4_machine_data += $player_head_add gm4_machine_data
execute store result score $player_head_add gm4_machine_data run clone ~-4 ~3 ~-4 ~4 ~3 ~1 ~-4 ~3 ~-4 filtered #gm4_machines:player_heads{components:{"minecraft:custom_data":{gm4_machines:{}}}} force
scoreboard players operation $player_head_count gm4_machine_data += $player_head_add gm4_machine_data
execute store result score $player_head_add gm4_machine_data run clone ~-4 ~4 ~-4 ~4 ~4 ~1 ~-4 ~4 ~-4 filtered #gm4_machines:player_heads{components:{"minecraft:custom_data":{gm4_machines:{}}}} force
scoreboard players operation $player_head_count gm4_machine_data += $player_head_add gm4_machine_data
execute store result score $player_head_add gm4_machine_data run clone ~-4 ~5 ~-4 ~4 ~5 ~1 ~-4 ~5 ~-4 filtered #gm4_machines:player_heads{components:{"minecraft:custom_data":{gm4_machines:{}}}} force
scoreboard players operation $player_head_count gm4_machine_data += $player_head_add gm4_machine_data
execute store result score $player_head_add gm4_machine_data run clone ~-4 ~6 ~-4 ~4 ~6 ~1 ~-4 ~6 ~-4 filtered #gm4_machines:player_heads{components:{"minecraft:custom_data":{gm4_machines:{}}}} force
scoreboard players operation $player_head_count gm4_machine_data += $player_head_add gm4_machine_data

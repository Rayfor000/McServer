advancement revoke @s only gm4_machines-1.4:place_machine_block
execute store result score $y_rotation gm4_machine_data run data get entity @s Rotation[0]
scoreboard players set $rotation gm4_machine_data 0
execute if score $y_rotation gm4_machine_data matches 45..135 run scoreboard players set $rotation gm4_machine_data 6
execute if score $rotation gm4_machine_data matches 0 if score $y_rotation gm4_machine_data matches -45..45 run scoreboard players set $rotation gm4_machine_data 5
execute if score $rotation gm4_machine_data matches 0 if score $y_rotation gm4_machine_data matches -135..-45 run scoreboard players set $rotation gm4_machine_data 4
execute if score $rotation gm4_machine_data matches 0 run scoreboard players set $rotation gm4_machine_data 3
scoreboard players operation $single_rotation gm4_machine_data = $rotation gm4_machine_data
scoreboard players remove $single_rotation gm4_machine_data 2
scoreboard players set $player_head_count gm4_machine_data 0
execute if score $rotation gm4_machine_data matches 3 run function gm4_machines-1.4:place_down/count_heads/north
execute if score $rotation gm4_machine_data matches 4 run function gm4_machines-1.4:place_down/count_heads/east
execute if score $rotation gm4_machine_data matches 5 run function gm4_machines-1.4:place_down/count_heads/south
execute if score $rotation gm4_machine_data matches 6 run function gm4_machines-1.4:place_down/count_heads/west
scoreboard players set $layer_count gm4_machine_data 0
execute if score $player_head_count gm4_machine_data matches 1.. if score $rotation gm4_machine_data matches 3 align xyz positioned ~0.5 ~0.5 ~0.5 rotated 180 0 positioned ^-4 ^-4 ^-1 run function gm4_machines-1.4:place_down/check_layer
execute if score $player_head_count gm4_machine_data matches 1.. if score $rotation gm4_machine_data matches 4 align xyz positioned ~0.5 ~0.5 ~0.5 rotated -90 0 positioned ^-4 ^-4 ^-1 run function gm4_machines-1.4:place_down/check_layer
execute if score $player_head_count gm4_machine_data matches 1.. if score $rotation gm4_machine_data matches 5 align xyz positioned ~0.5 ~0.5 ~0.5 rotated 0 0 positioned ^-4 ^-4 ^-1 run function gm4_machines-1.4:place_down/check_layer
execute if score $player_head_count gm4_machine_data matches 1.. if score $rotation gm4_machine_data matches 6 align xyz positioned ~0.5 ~0.5 ~0.5 rotated 90 0 positioned ^-4 ^-4 ^-1 run function gm4_machines-1.4:place_down/check_layer

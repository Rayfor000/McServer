advancement revoke @s only gm4_machines-1.4:place_machine_cart
tag @s add gm4_machines_placer
scoreboard players set $placed_block gm4_machine_data 0
execute as @e[type=#gm4:minecarts,tag=!gm4_machine_checked] if data entity @s CustomName at @s run function #gm4_machines:place_cart
tag @e[type=#gm4:minecarts] add gm4_machine_checked
tag @s remove gm4_machines_placer

tag @s add gm4_dimension
data merge entity @s {CustomName:"minecraft:overworld"}
function gm4_forceload-1.5:init_chunk
setblock 29999998 1 7131 minecraft:repeating_command_block{auto:1b,Command:"function #gm4_forceload:command_block_tick"}
summon armor_stand 29999999 0 7135 {"UUID":[I;3427655,262148,262159,80613453],"Invulnerable":1,"Invisible":1,"Marker":1,"Tags":["smithed.entity","smithed.strict"],"CustomName":"lib_forceload_armorstand"}
scoreboard players add #max gm4_dimension 1
scoreboard players operation @s gm4_dimension = #max gm4_dimension
tp @s 29999999 0 7135

advancement revoke @s only gm4_forceload-1.5:change_dimension
execute if block 29999998 1 7133 birch_wall_sign run return 0
function gm4_forceload-1.5:init_chunk
tag @s add gm4_in_new_dimension
execute summon minecraft:marker in minecraft:overworld run function gm4_forceload-1.5:set_marker_data
tag @s remove gm4_in_new_dimension

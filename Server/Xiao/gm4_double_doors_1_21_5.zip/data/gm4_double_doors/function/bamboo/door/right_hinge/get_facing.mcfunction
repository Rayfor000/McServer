execute if block ~ ~ ~ minecraft:bamboo_door[facing=east] run function gm4_double_doors:bamboo/door/right_hinge/east/find_neighbors
execute if block ~ ~ ~ minecraft:bamboo_door[facing=north] run function gm4_double_doors:bamboo/door/right_hinge/north/find_neighbors
execute if block ~ ~ ~ minecraft:bamboo_door[facing=south] run function gm4_double_doors:bamboo/door/right_hinge/south/find_neighbors
execute if block ~ ~ ~ minecraft:bamboo_door[facing=west] run function gm4_double_doors:bamboo/door/right_hinge/west/find_neighbors

function gm4_double_doors:bamboo/door/left_hinge/west/toggle
execute positioned ~ ~ ~-1 if block ~ ~ ~ minecraft:bamboo_door[hinge=right, facing=west] run function gm4_double_doors:bamboo/door/right_hinge/west/toggle
execute positioned ~-1 ~ ~ if block ~ ~ ~ minecraft:bamboo_door[hinge=right, facing=east] run function gm4_double_doors:bamboo/door/right_hinge/east/toggle

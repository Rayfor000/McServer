function gm4_double_doors:bamboo/door/right_hinge/east/toggle
execute positioned ~ ~ ~-1 if block ~ ~ ~ minecraft:bamboo_door[hinge=left, facing=east] run function gm4_double_doors:bamboo/door/left_hinge/east/toggle
execute positioned ~1 ~ ~ if block ~ ~ ~ minecraft:bamboo_door[hinge=left, facing=west] run function gm4_double_doors:bamboo/door/left_hinge/west/toggle

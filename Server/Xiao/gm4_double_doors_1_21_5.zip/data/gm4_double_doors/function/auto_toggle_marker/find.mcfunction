execute as @e[type=marker, tag=gm4_double_doors_auto_toggle_marker] at @s align xyz run function gm4_double_doors:auto_toggle_marker/maintain
execute if score $found_auto_toggle_marker gm4_double_doors_data matches 1.. run schedule function gm4_double_doors:auto_toggle_marker/find 1
scoreboard players reset $found_auto_toggle_marker gm4_double_doors_data

execute if entity @s[tag=gm4_double_doors_collision_box_east] as @a[dx=0, dy=1, dz=0, limit=1, gamemode=!spectator] positioned ~0.8125 ~ ~ if entity @s[dx=0, dy=1, dz=0] run return 1
execute if entity @s[tag=gm4_double_doors_collision_box_north] as @a[dx=0, dy=1, dz=0, limit=1, gamemode=!spectator] positioned ~ ~ ~-0.8125 if entity @s[dx=0, dy=1, dz=0] run return 1
execute if entity @s[tag=gm4_double_doors_collision_box_south] as @a[dx=0, dy=1, dz=0, limit=1, gamemode=!spectator] positioned ~ ~ ~0.8125 if entity @s[dx=0, dy=1, dz=0] run return 1
execute if entity @s[tag=gm4_double_doors_collision_box_west] as @a[dx=0, dy=1, dz=0, limit=1, gamemode=!spectator] positioned ~-0.8125 ~ ~ if entity @s[dx=0, dy=1, dz=0] run return 1
return fail

scoreboard players set @s gm4_double_doors_auto_toggle_state 2
scoreboard players set @s gm4_double_doors_auto_toggle_liftime 10

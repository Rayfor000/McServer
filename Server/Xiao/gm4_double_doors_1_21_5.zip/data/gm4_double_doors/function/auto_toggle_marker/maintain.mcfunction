scoreboard players remove @s gm4_double_doors_auto_toggle_liftime 1
execute if score @s gm4_double_doors_auto_toggle_state matches ..0 if function gm4_double_doors:auto_toggle_marker/player_present run scoreboard players set @s gm4_double_doors_auto_toggle_state 1
execute if score @s gm4_double_doors_auto_toggle_state matches 1 unless function gm4_double_doors:auto_toggle_marker/player_present run function gm4_double_doors:auto_toggle_marker/player_departed
execute if score @s gm4_double_doors_auto_toggle_state matches 2.. if score @s gm4_double_doors_auto_toggle_liftime matches 0 run function gm4_double_doors:auto_toggle_marker/select_material
execute if score @s gm4_double_doors_auto_toggle_liftime matches ..0 run kill @s
execute unless block ~ ~ ~ #minecraft:doors run kill @s
scoreboard players set $found_auto_toggle_marker gm4_double_doors_data 1

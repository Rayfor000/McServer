function gm4_double_doors:cherry/door/right_hinge/north/toggle
execute positioned ~-1 ~ ~ if block ~ ~ ~ minecraft:cherry_door[hinge=left, facing=north] run function gm4_double_doors:cherry/door/left_hinge/north/toggle
execute positioned ~ ~ ~-1 if block ~ ~ ~ minecraft:cherry_door[hinge=left, facing=south] run function gm4_double_doors:cherry/door/left_hinge/south/toggle

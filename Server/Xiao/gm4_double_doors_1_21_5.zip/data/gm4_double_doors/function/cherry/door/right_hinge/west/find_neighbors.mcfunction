function gm4_double_doors:cherry/door/right_hinge/west/toggle
execute positioned ~ ~ ~1 if block ~ ~ ~ minecraft:cherry_door[hinge=left, facing=west] run function gm4_double_doors:cherry/door/left_hinge/west/toggle
execute positioned ~-1 ~ ~ if block ~ ~ ~ minecraft:cherry_door[hinge=left, facing=east] run function gm4_double_doors:cherry/door/left_hinge/east/toggle

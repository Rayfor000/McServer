function gm4_double_doors:exposed_copper/door/left_hinge/east/toggle
execute positioned ~ ~ ~1 if block ~ ~ ~ minecraft:exposed_copper_door[hinge=right, facing=east] run function gm4_double_doors:exposed_copper/door/right_hinge/east/toggle
execute positioned ~1 ~ ~ if block ~ ~ ~ minecraft:exposed_copper_door[hinge=right, facing=west] run function gm4_double_doors:exposed_copper/door/right_hinge/west/toggle

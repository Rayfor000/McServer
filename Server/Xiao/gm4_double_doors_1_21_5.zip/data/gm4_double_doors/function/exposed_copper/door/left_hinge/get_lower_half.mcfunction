scoreboard players set $found gm4_double_doors_data 1
scoreboard players set $target_door_state gm4_double_doors_data 0
execute if block ~ ~ ~ minecraft:exposed_copper_door[open=true] run scoreboard players set $target_door_state gm4_double_doors_data 1
execute if block ~ ~ ~ minecraft:exposed_copper_door[half=upper] positioned ~ ~-1 ~ if block ~ ~ ~ minecraft:exposed_copper_door[half=lower] run function gm4_double_doors:exposed_copper/door/left_hinge/get_facing
execute if block ~ ~ ~ minecraft:exposed_copper_door[half=lower] if block ~ ~1 ~ minecraft:exposed_copper_door[half=upper] run function gm4_double_doors:exposed_copper/door/left_hinge/get_facing

function gm4_double_doors:exposed_copper/door/right_hinge/north/toggle
execute positioned ~-1 ~ ~ if block ~ ~ ~ minecraft:exposed_copper_door[hinge=left, facing=north] run function gm4_double_doors:exposed_copper/door/left_hinge/north/toggle
execute positioned ~ ~ ~-1 if block ~ ~ ~ minecraft:exposed_copper_door[hinge=left, facing=south] run function gm4_double_doors:exposed_copper/door/left_hinge/south/toggle

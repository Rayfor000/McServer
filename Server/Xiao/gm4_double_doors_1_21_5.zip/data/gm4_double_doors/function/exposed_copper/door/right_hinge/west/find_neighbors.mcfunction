function gm4_double_doors:exposed_copper/door/right_hinge/west/toggle
execute positioned ~ ~ ~1 if block ~ ~ ~ minecraft:exposed_copper_door[hinge=left, facing=west] run function gm4_double_doors:exposed_copper/door/left_hinge/west/toggle
execute positioned ~-1 ~ ~ if block ~ ~ ~ minecraft:exposed_copper_door[hinge=left, facing=east] run function gm4_double_doors:exposed_copper/door/left_hinge/east/toggle

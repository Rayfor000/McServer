function gm4_double_doors:copper/door/left_hinge/north/toggle
execute positioned ~1 ~ ~ if block ~ ~ ~ minecraft:copper_door[hinge=right, facing=north] run function gm4_double_doors:copper/door/right_hinge/north/toggle
execute positioned ~ ~ ~-1 if block ~ ~ ~ minecraft:copper_door[hinge=right, facing=south] run function gm4_double_doors:copper/door/right_hinge/south/toggle

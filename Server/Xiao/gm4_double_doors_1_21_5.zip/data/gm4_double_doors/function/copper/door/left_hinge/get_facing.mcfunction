execute if block ~ ~ ~ minecraft:copper_door[facing=east] run function gm4_double_doors:copper/door/left_hinge/east/find_neighbors
execute if block ~ ~ ~ minecraft:copper_door[facing=north] run function gm4_double_doors:copper/door/left_hinge/north/find_neighbors
execute if block ~ ~ ~ minecraft:copper_door[facing=south] run function gm4_double_doors:copper/door/left_hinge/south/find_neighbors
execute if block ~ ~ ~ minecraft:copper_door[facing=west] run function gm4_double_doors:copper/door/left_hinge/west/find_neighbors

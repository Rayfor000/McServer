scoreboard players set $found gm4_double_doors_data 0
execute align xyz positioned ~0.5 ~0.5 ~0.5 if block ~ ~ ~ minecraft:acacia_door[hinge=left] run function gm4_double_doors:acacia/door/left_hinge/get_lower_half
scoreboard players remove $ray gm4_double_doors_data 1
execute unless score $found gm4_double_doors_data matches 1 if score $ray gm4_double_doors_data matches 1.. positioned ^ ^ ^0.1 run function gm4_double_doors:acacia/door/left_hinge/ray

scoreboard players set $found gm4_double_doors_data 1
scoreboard players set $target_door_state gm4_double_doors_data 0
execute if block ~ ~ ~ minecraft:acacia_door[open=true] run scoreboard players set $target_door_state gm4_double_doors_data 1
execute if block ~ ~ ~ minecraft:acacia_door[half=upper] positioned ~ ~-1 ~ if block ~ ~ ~ minecraft:acacia_door[half=lower] run function gm4_double_doors:acacia/door/right_hinge/get_facing
execute if block ~ ~ ~ minecraft:acacia_door[half=lower] if block ~ ~1 ~ minecraft:acacia_door[half=upper] run function gm4_double_doors:acacia/door/right_hinge/get_facing

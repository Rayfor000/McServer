advancement revoke @s only gm4_double_doors:acacia/use_right_hinge_door
scoreboard players set $ray gm4_double_doors_data 50
scoreboard players set $found gm4_double_doors_data 0
execute anchored eyes positioned ^ ^ ^ run function gm4_double_doors:acacia/door/right_hinge/ray

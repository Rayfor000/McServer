execute if block ~ ~ ~ minecraft:acacia_door[facing=east] run function gm4_double_doors:acacia/door/right_hinge/east/find_neighbors
execute if block ~ ~ ~ minecraft:acacia_door[facing=north] run function gm4_double_doors:acacia/door/right_hinge/north/find_neighbors
execute if block ~ ~ ~ minecraft:acacia_door[facing=south] run function gm4_double_doors:acacia/door/right_hinge/south/find_neighbors
execute if block ~ ~ ~ minecraft:acacia_door[facing=west] run function gm4_double_doors:acacia/door/right_hinge/west/find_neighbors

execute if score $target_door_state gm4_double_doors_data matches 0 run place template gm4_double_doors:acacia/door/north/right/closed ~ ~ ~
execute if score $target_door_state gm4_double_doors_data matches 1 run place template gm4_double_doors:acacia/door/north/right/open ~ ~ ~
execute store result score $target_trapdoor_state gm4_double_doors_data if score $target_door_state gm4_double_doors_data matches 1
scoreboard players operation $trap_door_recursion_level gm4_double_doors_data = $trap_door_limit gm4_double_doors_data
execute positioned ~ ~2 ~ if block ~ ~ ~ minecraft:acacia_trapdoor[open=true, half=bottom] unless block ~ ~ ~ minecraft:acacia_trapdoor[facing=east] unless block ~ ~ ~ minecraft:acacia_trapdoor[facing=south] run function gm4_double_doors:acacia/trapdoor/north_west/check_neighbours
execute align xyz store success score $found_prexisting_marker gm4_double_doors_data run kill @e[type=marker, tag=gm4_double_doors_auto_toggle_marker, dx=0]
execute unless score $triggered_by_auto_toggle gm4_double_doors_data matches 1 if score $found_prexisting_marker gm4_double_doors_data matches 0 summon marker run function gm4_double_doors:acacia/door/right_hinge/north/initialize_auto_toggle_marker
execute if score $triggered_by_auto_toggle gm4_double_doors_data matches 1 run scoreboard players set $play_sound gm4_double_doors_data 1
scoreboard players reset $found_prexisting_marker gm4_double_doors_data

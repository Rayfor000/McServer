execute if score $target_trapdoor_state gm4_double_doors_data matches 0 run setblock ~ ~ ~ acacia_trapdoor[open=true, half=bottom, facing=south]
execute if score $target_trapdoor_state gm4_double_doors_data matches 1 run setblock ~ ~ ~ acacia_trapdoor[open=true, half=bottom, facing=west]

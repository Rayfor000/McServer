function gm4_double_doors:acacia/trapdoor/south_west/toggle
scoreboard players remove $trap_door_recursion_level gm4_double_doors_data 1
execute if score $trap_door_recursion_level gm4_double_doors_data matches 1.. positioned ~ ~1 ~ if block ~ ~ ~ minecraft:acacia_trapdoor[open=true, half=bottom] unless block ~ ~ ~ minecraft:acacia_trapdoor[facing=east] unless block ~ ~ ~ minecraft:acacia_trapdoor[facing=north] run function gm4_double_doors:acacia/trapdoor/south_west/check_neighbours

function gm4_double_doors:dark_oak/trapdoor/north_east/toggle
scoreboard players remove $trap_door_recursion_level gm4_double_doors_data 1
execute if score $trap_door_recursion_level gm4_double_doors_data matches 1.. positioned ~ ~1 ~ if block ~ ~ ~ minecraft:dark_oak_trapdoor[open=true, half=bottom] unless block ~ ~ ~ minecraft:dark_oak_trapdoor[facing=west] unless block ~ ~ ~ minecraft:dark_oak_trapdoor[facing=south] run function gm4_double_doors:dark_oak/trapdoor/north_east/check_neighbours

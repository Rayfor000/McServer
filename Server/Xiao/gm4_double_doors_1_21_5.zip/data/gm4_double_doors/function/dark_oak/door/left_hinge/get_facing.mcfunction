execute if block ~ ~ ~ minecraft:dark_oak_door[facing=east] run function gm4_double_doors:dark_oak/door/left_hinge/east/find_neighbors
execute if block ~ ~ ~ minecraft:dark_oak_door[facing=north] run function gm4_double_doors:dark_oak/door/left_hinge/north/find_neighbors
execute if block ~ ~ ~ minecraft:dark_oak_door[facing=south] run function gm4_double_doors:dark_oak/door/left_hinge/south/find_neighbors
execute if block ~ ~ ~ minecraft:dark_oak_door[facing=west] run function gm4_double_doors:dark_oak/door/left_hinge/west/find_neighbors

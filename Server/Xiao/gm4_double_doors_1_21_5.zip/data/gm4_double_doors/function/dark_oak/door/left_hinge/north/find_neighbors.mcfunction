function gm4_double_doors:dark_oak/door/left_hinge/north/toggle
execute positioned ~1 ~ ~ if block ~ ~ ~ minecraft:dark_oak_door[hinge=right, facing=north] run function gm4_double_doors:dark_oak/door/right_hinge/north/toggle
execute positioned ~ ~ ~-1 if block ~ ~ ~ minecraft:dark_oak_door[hinge=right, facing=south] run function gm4_double_doors:dark_oak/door/right_hinge/south/toggle

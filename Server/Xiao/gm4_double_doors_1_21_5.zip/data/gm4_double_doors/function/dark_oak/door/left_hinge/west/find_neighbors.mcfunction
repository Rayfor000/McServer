function gm4_double_doors:dark_oak/door/left_hinge/west/toggle
execute positioned ~ ~ ~-1 if block ~ ~ ~ minecraft:dark_oak_door[hinge=right, facing=west] run function gm4_double_doors:dark_oak/door/right_hinge/west/toggle
execute positioned ~-1 ~ ~ if block ~ ~ ~ minecraft:dark_oak_door[hinge=right, facing=east] run function gm4_double_doors:dark_oak/door/right_hinge/east/toggle

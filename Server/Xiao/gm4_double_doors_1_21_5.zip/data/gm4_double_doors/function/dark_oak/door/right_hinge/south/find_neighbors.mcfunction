function gm4_double_doors:dark_oak/door/right_hinge/south/toggle
execute positioned ~1 ~ ~ if block ~ ~ ~ minecraft:dark_oak_door[hinge=left, facing=south] run function gm4_double_doors:dark_oak/door/left_hinge/south/toggle
execute positioned ~ ~ ~1 if block ~ ~ ~ minecraft:dark_oak_door[hinge=left, facing=north] run function gm4_double_doors:dark_oak/door/left_hinge/north/toggle

function gm4_double_doors:jungle/door/left_hinge/east/toggle
execute positioned ~ ~ ~1 if block ~ ~ ~ minecraft:jungle_door[hinge=right, facing=east] run function gm4_double_doors:jungle/door/right_hinge/east/toggle
execute positioned ~1 ~ ~ if block ~ ~ ~ minecraft:jungle_door[hinge=right, facing=west] run function gm4_double_doors:jungle/door/right_hinge/west/toggle

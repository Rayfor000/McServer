function gm4_double_doors:crimson/door/left_hinge/east/toggle
execute positioned ~ ~ ~1 if block ~ ~ ~ minecraft:crimson_door[hinge=right, facing=east] run function gm4_double_doors:crimson/door/right_hinge/east/toggle
execute positioned ~1 ~ ~ if block ~ ~ ~ minecraft:crimson_door[hinge=right, facing=west] run function gm4_double_doors:crimson/door/right_hinge/west/toggle

function gm4_double_doors:birch/trapdoor/south_west/toggle
scoreboard players remove $trap_door_recursion_level gm4_double_doors_data 1
execute if score $trap_door_recursion_level gm4_double_doors_data matches 1.. positioned ~ ~1 ~ if block ~ ~ ~ minecraft:birch_trapdoor[open=true, half=bottom] unless block ~ ~ ~ minecraft:birch_trapdoor[facing=east] unless block ~ ~ ~ minecraft:birch_trapdoor[facing=north] run function gm4_double_doors:birch/trapdoor/south_west/check_neighbours

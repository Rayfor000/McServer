function gm4_double_doors:birch/door/left_hinge/east/toggle
execute positioned ~ ~ ~1 if block ~ ~ ~ minecraft:birch_door[hinge=right, facing=east] run function gm4_double_doors:birch/door/right_hinge/east/toggle
execute positioned ~1 ~ ~ if block ~ ~ ~ minecraft:birch_door[hinge=right, facing=west] run function gm4_double_doors:birch/door/right_hinge/west/toggle

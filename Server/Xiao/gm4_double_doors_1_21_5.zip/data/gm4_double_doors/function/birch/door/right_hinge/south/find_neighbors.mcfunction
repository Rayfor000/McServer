function gm4_double_doors:birch/door/right_hinge/south/toggle
execute positioned ~1 ~ ~ if block ~ ~ ~ minecraft:birch_door[hinge=left, facing=south] run function gm4_double_doors:birch/door/left_hinge/south/toggle
execute positioned ~ ~ ~1 if block ~ ~ ~ minecraft:birch_door[hinge=left, facing=north] run function gm4_double_doors:birch/door/left_hinge/north/toggle

summon minecraft:piglin_brute ~ ~ ~ {"Tags":["gm4_es_new_mob"]}
tp @e[type=piglin_brute, tag=gm4_es_new_mob, limit=1, distance=..0.01] @s
tag @s add gm4_es_old_mob
execute on vehicle run ride @e[type=piglin_brute, tag=gm4_es_new_mob, limit=1, distance=..0.01] mount @s
execute on vehicle run ride @e[type=piglin, tag=gm4_es_old_mob, limit=1, distance=..0.01] dismount
execute on passengers run ride @s dismount
effect give @s nausea 1 2
data merge entity @s {Tags:[]}
data modify entity @e[type=piglin_brute, tag=gm4_es_new_mob, limit=1] {} merge from entity @s
playsound minecraft:entity.piglin_brute.ambient hostile @a[distance=..16] ~ ~ ~ 0.5
playsound block.redstone_torch.burnout hostile @a[distance=..16] ~ ~ ~ 0.5 0.1
data merge entity @s {DeathTime:19s,Health:0,DeathLootTable:"gm4:empty",drop_chances:{mainhand:0.0f,offhand:0.0f,feet:0.0f,legs:0.0f,chest:0.0f,head:0.0f}}
tp @s ~ ~-5000 ~

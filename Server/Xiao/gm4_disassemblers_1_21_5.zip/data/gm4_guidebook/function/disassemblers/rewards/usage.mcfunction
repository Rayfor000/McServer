tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Disassemblers]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Disassemblers",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.disassemblers",fallback:"Break apart gold and iron tools and weapons for materials. Attach this to a mob farm to finally make use of those extra armour sets!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:disassemblers/display/usage
advancement grant @s only gm4_guidebook:disassemblers/unlock/description
function gm4_guidebook:disassemblers/rewards/unlock/usage

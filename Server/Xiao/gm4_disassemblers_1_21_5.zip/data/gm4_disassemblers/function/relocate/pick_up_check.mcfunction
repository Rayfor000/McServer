execute if score gm4_disassemblers load.status matches 1.. if entity @s[tag=gm4_disassembler] run function gm4_disassemblers:relocate/set_pick_up_data

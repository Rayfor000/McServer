scoreboard players set $placed_block gm4_rl_data 1
summon armor_stand ~ ~-0.4 ~ {"Small":1,"NoGravity":1,"Marker":1,"Invulnerable":1,"Invisible":1,"Silent":1,"DisabledSlots":4144959,"Tags":["gm4_no_edit","gm4_disassembler_stand","gm4_machine_stand","smithed.entity","smithed.strict","gm4_new_machine"],"HasVisualFire":1,"CustomName":"gm4_disassembler_stand","equipment":{"head":{"id":"minecraft:tnt","count":1,"components":{"minecraft:custom_model_data":{"floats":[3420001]}}}},"Rotation":[0.0,0.0]}
summon marker ~ ~ ~ {"Tags":["gm4_disassembler","gm4_machine_marker","smithed.block","smithed.entity","smithed.strict","gm4_new_machine"],"CustomName":"gm4_disassembler","Rotation":[0.0,0.0]}
execute as @e[tag=gm4_new_machine, distance=..2] run data modify entity @s Rotation set from storage gm4_relocators:temp gm4_relocation.entity_data.Rotation
execute as @e[tag=gm4_new_machine, distance=..2] at @s rotated as @e[type=marker, tag=gm4_new_machine, distance=..2, limit=1] run tp ~ ~ ~
execute as @e[type=armor_stand, tag=gm4_new_machine, distance=..2] run data modify entity @s equipment set from storage gm4_relocators:temp gm4_relocation.entity_data.equipment
scoreboard players set @e[distance=..2, tag=gm4_new_machine] gm4_entity_version 1
tag @e[distance=..2] remove gm4_new_machine

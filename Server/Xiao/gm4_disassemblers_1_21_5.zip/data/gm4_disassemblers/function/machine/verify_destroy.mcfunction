execute if entity @s[tag=gm4_disassembler] run function gm4_disassemblers:machine/destroy

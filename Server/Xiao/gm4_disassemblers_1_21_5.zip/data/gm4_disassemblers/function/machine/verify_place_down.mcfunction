execute if score $placed_block gm4_machine_data matches 0 if data storage gm4_machines:temp {id:"disassembler"} run function gm4_disassemblers:machine/create

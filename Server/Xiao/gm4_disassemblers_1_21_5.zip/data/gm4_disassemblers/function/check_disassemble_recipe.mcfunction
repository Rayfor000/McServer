execute if score $dropped gm4_disassembler matches 0 store result score $dropped gm4_disassembler run loot replace block ~ ~ ~ container.0 fish gm4_disassemblers:caller ~ ~ ~ mainhand
